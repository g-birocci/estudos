lis_ta = [1,2,3,4,5,6,7,8,9,10]
lis_ta.remove (5)
lis_ta.append(11)
print(lis_ta)