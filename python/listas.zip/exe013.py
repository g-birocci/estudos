lis_ta = ["maçã","banana","laranja","uva"]
print(len(lis_ta))
print(lis_ta[0])
print(lis_ta[-1])