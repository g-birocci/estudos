/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula02;

/**
 *
 * @author gabri
 */
public class Aula02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int n1 = 5 + (8 * 6);
        double n2 = (55 + 9) % 9;
        double n3 = 20 + (-3 * 5) / 8;
        double n4 = 5 + (15 / 3) * 2 - 8 % 3;
        
        System.out.println("A = " + n1);
        System.out.println("B = " + n2);
        System.out.println("C = " + n3);
        System.out.println("D = " + n4);
        
    }
}
