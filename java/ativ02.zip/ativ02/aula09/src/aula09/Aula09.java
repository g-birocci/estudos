/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula09;

/**
 *
 * @author gabri
 */
public class Aula09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int[] meuarrey = {10,20,30,40,50};
       
       for( int posi = 0; posi < meuarrey.length; posi ++){       
            System.out.printf("%d %s %d \n", posi, "=>" , meuarrey[ posi ]);
        }
  
    }
    
}
